
# FightZone — Flask + MySQL (MVP)

## Requisitos
- Python 3.10+
- MySQL 8.x

## Instalación
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scriptsctivate
pip install -r requirements.txt
cp .env.example .env  # edita las variables
```

## Base de datos
Ejecuta `db/schema.sql` en tu MySQL.

```bash
mysql -u <usuario> -p < db/schema.sql
```

## Arranque
```bash
flask --app app.py run
# o
python app.py
```

Abre http://127.0.0.1:5000/

## Admin
1. Regístrate con tu email.
2. En MySQL ejecuta: `UPDATE usuarios SET rol='admin' WHERE email='tu@correo.com';`
3. Entra a `/admin/products`.

## Notas
- Contraseñas: hash PBKDF2-SHA256 con salt (Werkzeug).
- Subida de imágenes: carpeta `static/uploads`.
- Si no subes imagen ni URL, se usa `emoji:🥊`.
- La home trae 6 productos demo con IDs 1..6. Puedes cambiarlos desde el panel Admin.
