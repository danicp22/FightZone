
import os, time
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from db import get_db, close_db

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'dev')

UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
ALLOWED_EXTS = {'png', 'jpg', 'jpeg', 'webp', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTS

@app.teardown_appcontext
def teardown_db(exception):
    close_db()

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            if request.is_json or request.headers.get('X-Requested-With') == 'fetch':
                return jsonify({'ok': False, 'message': 'auth required'}), 401
            return redirect(url_for('login', next=request.path))
        return f(*args, **kwargs)
    return wrapper

def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get('rol') != 'admin':
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return wrapper

from db import get_db

def get_cart_id(user_id):
    db = get_db()
    with db.cursor() as cur:
        cur.execute("SELECT id FROM carrito WHERE usuario_id=%s ORDER BY id DESC LIMIT 1", (user_id,))
        row = cur.fetchone()
        if row:
            return row['id']
        cur.execute("INSERT INTO carrito (usuario_id) VALUES (%s)", (user_id,))
        db.commit()
        return cur.lastrowid

def get_cart_count(user_id):
    db = get_db()
    with db.cursor() as cur:
        cur.execute(
            """
            SELECT COALESCE(SUM(ci.cantidad),0) AS cnt
            FROM carrito c
            LEFT JOIN carrito_items ci ON ci.carrito_id=c.id
            WHERE c.usuario_id=%s
            """,
            (user_id,),
        )
        row = cur.fetchone()
        return (row and row.get('cnt')) or 0

@app.route('/')
def index():
    ccount = get_cart_count(session['user_id']) if 'user_id' in session else 0
    return render_template('index.html', cart_count=ccount, user=session.get('nombre'), rol=session.get('rol'))

@app.route('/products')
def products():
    cat = request.args.get('cat')
    db = get_db()
    with db.cursor() as cur:
        cur.execute("SELECT * FROM categorias")
        cats = cur.fetchall()
        if cat and cat.isdigit():
            cur.execute(
                """
                SELECT p.*, c.nombre AS categoria
                FROM productos p LEFT JOIN categorias c ON c.id=p.categoria_id
                WHERE categoria_id=%s
                """,
                (cat,),
            )
        else:
            cur.execute(
                """
                SELECT p.*, c.nombre AS categoria
                FROM productos p LEFT JOIN categorias c ON c.id=p.categoria_id
                """
            )
        prods = cur.fetchall()
    ccount = get_cart_count(session['user_id']) if 'user_id' in session else 0
    return render_template('products.html', productos=prods, categorias=cats, sel=cat, cart_count=ccount, user=session.get('nombre'), rol=session.get('rol'))

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        nombre = request.form.get('nombre','').strip()
        email = request.form.get('email','').strip().lower()
        password = request.form.get('password','')
        if not nombre or not email or not password:
            flash('Rellena todos los campos', 'error')
            return redirect(url_for('register'))
        hpw = generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)
        db = get_db()
        try:
            with db.cursor() as cur:
                cur.execute("INSERT INTO usuarios (nombre,email,password) VALUES (%s,%s,%s)", (nombre,email,hpw))
            db.commit()
            flash('Cuenta creada, inicia sesión', 'ok')
            return redirect(url_for('login'))
        except Exception:
            db.rollback()
            flash('El email ya existe o ha ocurrido un error', 'error')
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email','').strip().lower()
        password = request.form.get('password','')
        db = get_db()
        with db.cursor() as cur:
            cur.execute("SELECT * FROM usuarios WHERE email=%s", (email,))
            u = cur.fetchone()
        if not u or not check_password_hash(u['password'], password):
            flash('Credenciales incorrectas', 'error')
            return redirect(url_for('login'))
        session['user_id'] = u['id']
        session['nombre'] = u['nombre']
        session['rol'] = u['rol']
        nxt = request.args.get('next') or url_for('index')
        return redirect(nxt)
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/cart')
@login_required
def cart():
    user_id = session['user_id']
    cid = get_cart_id(user_id)
    db = get_db()
    with db.cursor() as cur:
        cur.execute(
            """
            SELECT ci.id, p.id AS producto_id, p.nombre, p.precio, p.imagen, ci.cantidad,
                   (p.precio*ci.cantidad) AS subtotal
            FROM carrito_items ci
            JOIN productos p ON p.id=ci.producto_id
            WHERE ci.carrito_id=%s
            """,
            (cid,),
        )
        items = cur.fetchall()
    total = sum(i['subtotal'] for i in items) if items else 0
    return render_template('cart.html', items=items, total=total, cart_count=get_cart_count(user_id), user=session.get('nombre'), rol=session.get('rol'))

@app.route('/cart/add', methods=['POST'])
@login_required
def cart_add():
    data = request.get_json(silent=True) or {}
    pid = data.get('product_id')
    try:
        qty = int(data.get('cantidad', 1))
    except Exception:
        qty = 1
    if not pid or qty < 1:
        return jsonify({'ok': False, 'message': 'datos inválidos'}), 400
    user_id = session['user_id']
    cid = get_cart_id(user_id)
    db = get_db()
    try:
        with db.cursor() as cur:
            cur.execute("SELECT stock FROM productos WHERE id=%s", (pid,))
            row = cur.fetchone()
            if not row:
                return jsonify({'ok': False, 'message': 'producto no existe'}), 404
            cur.execute("SELECT id,cantidad FROM carrito_items WHERE carrito_id=%s AND producto_id=%s", (cid,pid))
            ex = cur.fetchone()
            if ex:
                cur.execute("UPDATE carrito_items SET cantidad=cantidad+%s WHERE id=%s", (qty, ex['id']))
            else:
                cur.execute("INSERT INTO carrito_items (carrito_id, producto_id, cantidad) VALUES (%s,%s,%s)", (cid,pid,qty))
        db.commit()
    except Exception:
        db.rollback()
        return jsonify({'ok': False}), 500
    return jsonify({'ok': True, 'count': get_cart_count(user_id)})

@app.route('/cart/update', methods=['POST'])
@login_required
def cart_update():
    item_id = request.form.get('item_id')
    qty = int(request.form.get('cantidad', 1))
    if qty < 1:
        return redirect(url_for('cart'))
    db = get_db()
    with db.cursor() as cur:
        cur.execute("UPDATE carrito_items SET cantidad=%s WHERE id=%s", (qty, item_id))
    db.commit()
    return redirect(url_for('cart'))

@app.route('/cart/remove', methods=['POST'])
@login_required
def cart_remove():
    item_id = request.form.get('item_id')
    db = get_db()
    with db.cursor() as cur:
        cur.execute("DELETE FROM carrito_items WHERE id=%s", (item_id,))
    db.commit()
    return redirect(url_for('cart'))

@app.route('/cart/count')
def cart_count():
    if 'user_id' not in session:
        return jsonify({'count': 0})
    return jsonify({'count': get_cart_count(session['user_id'])})

@app.route('/checkout', methods=['GET','POST'])
@login_required
def checkout():
    user_id = session['user_id']
    cid = get_cart_id(user_id)
    db = get_db()
    if request.method == 'POST':
        try:
            with db.cursor() as cur:
                cur.execute(
                    """
                    SELECT ci.id, ci.cantidad, p.id AS producto_id, p.stock
                    FROM carrito_items ci JOIN productos p ON p.id=ci.producto_id
                    WHERE ci.carrito_id=%s
                    """,
                    (cid,),
                )
                rows = cur.fetchall()
                for r in rows:
                    if r['cantidad'] > r['stock']:
                        raise ValueError('Sin stock suficiente')
                for r in rows:
                    cur.execute("UPDATE productos SET stock=stock-%s WHERE id=%s", (r['cantidad'], r['producto_id']))
                cur.execute("DELETE FROM carrito_items WHERE carrito_id=%s", (cid,))
            db.commit()
            flash('Pedido completado. ¡Gracias!','ok')
            return redirect(url_for('products'))
        except Exception as e:
            db.rollback()
            flash('No se pudo completar el pedido: ' + str(e),'error')
    with db.cursor() as cur:
        cur.execute(
            """
            SELECT p.nombre, p.precio, ci.cantidad, (p.precio*ci.cantidad) subtotal
            FROM carrito_items ci JOIN productos p ON p.id=ci.producto_id
            WHERE ci.carrito_id=%s
            """,
            (cid,),
        )
        items = cur.fetchall()
    total = sum(i['subtotal'] for i in items) if items else 0
    return render_template('checkout.html', items=items, total=total, cart_count=get_cart_count(user_id), user=session.get('nombre'), rol=session.get('rol'))

@app.route('/admin/products', methods=['GET','POST'])
@admin_required
def admin_products():
    db = get_db()
    if request.method == 'POST':
        nombre = request.form.get('nombre', '').strip()
        descripcion = request.form.get('descripcion', '').strip()
        precio = request.form.get('precio', '').strip()
        categoria_id = request.form.get('categoria_id', '').strip()
        stock = request.form.get('stock', '0').strip()

        imagen_url = request.form.get('imagen_url', '').strip()
        f = request.files.get('imagen_file')
        imagen_path = None
        try:
            if f and f.filename:
                if not allowed_file(f.filename):
                    flash('Formato de imagen no permitido', 'error')
                    return redirect(url_for('admin_products'))
                filename = secure_filename(f.filename)
                name, ext = os.path.splitext(filename)
                filename = f"{name}_{int(time.time())}{ext}"
                f.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                imagen_path = f"/static/uploads/{filename}"
            elif imagen_url:
                imagen_path = imagen_url
            else:
                imagen_path = 'emoji:🥊'
            with db.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO productos (nombre, descripcion, precio, imagen, categoria_id, stock)
                    VALUES (%s,%s,%s,%s,%s,%s)
                    """,
                    (nombre, descripcion, precio, imagen_path, categoria_id, stock),
                )
            db.commit()
            flash('Producto creado','ok')
            return redirect(url_for('admin_products'))
        except Exception as e:
            db.rollback()
            flash('Error al crear producto: ' + str(e),'error')
            return redirect(url_for('admin_products'))

    with db.cursor() as cur:
        cur.execute("SELECT * FROM categorias ORDER BY nombre")
        cats = cur.fetchall()
        cur.execute(
            """
            SELECT p.*, c.nombre AS categoria
            FROM productos p
            LEFT JOIN categorias c ON c.id=p.categoria_id
            ORDER BY p.id DESC
            """
        )
        prods = cur.fetchall()
    return render_template('admin_products.html', productos=prods, categorias=cats, cart_count=get_cart_count(session['user_id']) if 'user_id' in session else 0, user=session.get('nombre'), rol=session.get('rol'))

if __name__ == '__main__':
    app.run(debug=True)
